/******************** (C) COPYRIGHT 2019 STMicroelectronics **************************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V1.0.0
* Date               : 01/08/2019
* Description        : This file describes how to add STM32L4P5xx devices support on MDK-ARM 
**************************************************************************************************

Running the "Keil.STM32L4P5xx_DFP.1.0.0.pack" adds the following:
  
1. Part numbers for  :
- Product lines: STM32L4P5xx/L4Q5xx

2. Automatic STM32L4P5 flash algorithm selection 
- For the devices with Dual/Single Bank configuration, we use the Flash Loader
"STM32L4P5xx_1M.FLM"
    
3. SVD files for each RPNs.


How to use:
==========
* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
or later installed. 
You can download pack from keil web site @ www.keil.com
 
* Double Clic on  "Keil.STM32L4P5xx_DFP.1.0.0.pack" in order to install this pack in 
the Keil install directory.

******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE************************





	



